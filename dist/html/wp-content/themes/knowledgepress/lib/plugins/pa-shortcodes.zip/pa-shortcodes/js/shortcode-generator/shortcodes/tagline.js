gpShortcodeMeta={
	attributes:[
		{
			label:"Content",
			id:"content",
			controlType: 'textarea-control',
			help: 'Use a &lt;br /&gt; to start a new line.',
			isRequired:true
		}
		],
		shortcode:"tagline"
};