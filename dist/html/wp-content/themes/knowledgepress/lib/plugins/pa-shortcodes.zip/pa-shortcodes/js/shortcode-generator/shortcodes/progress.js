gpShortcodeMeta={
	attributes:[
		{
			label:"Animate",
			id:"animate",
			selectValues:[{'No':'on'}, {'Off':'off'}],
			defaultValue: 'off', 
			defaultText: 'Off (Default)'
		},
		{
			label:"Type",
			id:"type",
		},
		{
			label:"striped",
			id:"striped",
			selectValues:[{'No':'on'}, {'Off':'off'}],
			defaultValue: 'off', 
			defaultText: 'Off (Default)'
		},
		{
			label:"Width",
			id:"width",
		}
		],
		defaultContent:"",
		shortcode:"progress"
};