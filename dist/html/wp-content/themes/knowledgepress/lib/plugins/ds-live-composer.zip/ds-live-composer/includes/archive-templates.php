<?php

function dslc_archive_template_redirect( $archive_template ) {

	global $post;

	$template = dslc_get_option( $post->post_type, 'dslc_plugin_options_archives' );
	if ( ! $template || $template == 'none' ) return $archive_template;

	$archive_template = DS_LIVE_COMPOSER_ABS . '/templates/dslc-archive.php';
	return $archive_template;

}
add_filter( 'archive_template', 'dslc_archive_template_redirect' );
add_filter( 'category_template', 'dslc_archive_template_redirect' );

function dslc_archive_template_init() {

	global $dslc_plugin_options;
	global $dslc_var_modules;
	global $dslc_post_types;

	$opts = array();

	// Page Options
	$pages_opts = array();
	$pages_opts[] = array(
		'label' => __( 'Default', 'dslc_string' ),
		'value' => 'none'
	);
	$pages = get_pages();	
	foreach ( $pages as $page ) {
		$pages_opts[] = array(
			'label' => $page->post_title,
			'value' => $page->ID
		);
	}

	// Post types
	foreach ( $dslc_post_types as $post_type ) {

		$opts[$post_type] = array(
			'label' => $post_type . ' archives',
			'descr' => __( 'Choose which page should serve as template.', 'dslc_string' ),
			'std' => 'none',
			'type' => 'select',
			'choices' => $pages_opts
		);

	}

	/**
	 * Archive Tempalte Settings
	 */

	$dslc_plugin_options['dslc_plugin_options_archives'] = array(
		'title' => __( 'Archives Settings', 'dslc_string' ),
		'options' => $opts
	);
	

} add_action( 'dslc_hook_register_options', 'dslc_archive_template_init' );