<?php
function pafa_help_tab(){
	$screen = get_current_screen();
	if(in_array($screen->id,array('edit-faq_category','faq','edit-faq'))){
		$screen->add_help_tab( array(
			'id'	=> 'pressappsfaq_shortcode',
			'title'	=> __( 'Faq Shortcodes', 'pressapps' ),
			'content'	=>
			'<p>' . __('<h2>Faq Shortcodes</h2>','pressapps') . '</p>' .
			'<p>' . __( 'You can use <code>[faq]</code> shortcode to include the Faqs on any page, post or custom post type.', 'pressapps' ) . '</p>' .
			'<p>' . __( 'The shortcode accepts two optional attributes:', 'pressapps' ) . '</p>' .
			'<p>' . __( '(1) <b>category</b> = <i>-1</i> <b>|</b> <i>{any faq category id}</i>', 'pressapps' ) . '</p>' .
			'<p>' . __( '(2) <b>template</b> = <i>accordion</i> <b>|</b> <i>{any custom/existing template}</i>', 'pressapps' ) . '</p>' .
			'<p>' . __( '<b>Examples</b>', 'pressapps' ) . '</p>' .
			'<p>' . __( '1. <code>[faq]</code>', 'pressapps' ) . '</p>' .
			'<p>' . sprintf(__( '2. <code>[faq category={category_id}]</code> {category_id} you will find it <a href="%s">here</a> under shortcode column', 'pressapps' ),admin_url('edit-tags.php?taxonomy=faq_category&post_type=faq') ). '</p>' .
			'<p>' . __( '3. <code>[faq category={category_id} template=\'accordion\']</code>', 'pressapps' ) . '</p>'
		));
	}
}
add_action( 'admin_print_styles', 'pafa_help_tab');
add_action( 'admin_print_styles', 'pafa_help_tab');