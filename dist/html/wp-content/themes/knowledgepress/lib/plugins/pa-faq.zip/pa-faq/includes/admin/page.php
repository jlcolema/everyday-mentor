<?php

/*-----------------------------------------------------------------------------------*/
/* Register the admin page with the 'admin_menu' */
/*-----------------------------------------------------------------------------------*/

function pafa_admin_menu() {
	$page = add_submenu_page( 'options-general.php', __( 'PA FAQ', 'pressapps' ), __( 'PA FAQ', 'pressapps' ), 'manage_options', 'faq-options', 'pafa_options', 99 );
}
add_action( 'admin_menu', 'pafa_admin_menu' );


/*-----------------------------------------------------------------------------------*/
/* Load HTML that will create the outter shell of the admin page */
/*-----------------------------------------------------------------------------------*/

function pafa_options() {

	// Check that the user is able to view this page.
	if ( ! current_user_can( 'manage_options' ) )
		wp_die( __( 'You do not have sufficient permissions to access this page.', 'pressapps' ) ); ?>

	<div class="wrap">
		<div id="icon-themes" class="icon32"></div>
		<h2><?php _e( 'PA Faq Settings', 'pressapps' ); ?></h2>

		<form action="options.php" method="post">
			<?php settings_fields( 'pafa_setup_options' ); ?>
			<?php do_settings_sections( 'pafa_setup_options' ); ?>
			<?php submit_button(); ?>
		</form>

	</div>
<?php }

/*-----------------------------------------------------------------------------------*/
/* Registers all sections and fields with the Settings API */
/*-----------------------------------------------------------------------------------*/

function pafa_init_settings_registration() {
	$option_name = 'pafa_options';

	// Check if settings options exist in the database. If not, add them.
	if ( get_option( $option_name ) )
		add_option( $option_name );

	// Define settings sections.
	add_settings_section( 'pafa_setup_section', __( 'Setup', 'pressapps' ), 'pafa_setup_options', 'pafa_setup_options' );

	add_settings_field( 'reorder', __( 'Reorder', 'pressapps' ), 'pafa_settings_field_select', 'pafa_setup_options', 'pafa_setup_section', array(
		'options-name' => $option_name,
		'id'				=> 'reorder',
		'class' 			=> '',
		'value'			=> array(
								'0' => __( 'Disabled', 'pressapps' ),
								'1' => __( 'Enabled', 'pressapps' ),
								),
		'label'			=> __( 'Enable faq posts and categories drag and drop reorder feature.', 'pressapps' ),
	) );
	add_settings_field( 'custom_css', __( 'Custom CSS', 'pressapps' ), 'pafa_settings_field_textarea', 'pafa_setup_options', 'pafa_setup_section', array(
		'options-name' => $option_name,
		'id'				=> 'custom-css',
		'class'			=> '',
		'value'			=> '',
		'label'			=> __( 'Add custom CSS code.', 'pressapps' ),
	) );


	// Register settings with WordPress so we can save to the Database
	register_setting( 'pafa_setup_options', $option_name, 'pafa_options_sanitize' );
}
add_action( 'admin_init', 'pafa_init_settings_registration' );

/*-----------------------------------------------------------------------------------*/
/* add_settings_section() function for the widget options */
/*-----------------------------------------------------------------------------------*/

function pafa_setup_options() {
	//echo '<p>' . __( 'You can add video posts to your site using [video] shortcode.', 'pressapps' ) . '.</p>';
}

/*-----------------------------------------------------------------------------------*/
/* he callback function to display textareas */
/*-----------------------------------------------------------------------------------*/

function pafa_settings_field_textarea( $args ) {
	// Set the options-name value to a variable
	$name = $args['options-name'] . '[' . $args['id'] . ']';

	// Get the options from the database
	$options = get_option( $args['options-name'] ); ?>

	<label for="<?php echo $args['id']; ?>"><?php esc_attr_e( $args['label'] ); ?></label><br />
	<textarea name="<?php echo $name; ?>" id="<?php echo $args['id']; ?>" class="<?php if ( ! empty( $args['class'] ) ) echo ' ' . $args['class']; ?>" cols="60" rows="7"><?php esc_attr_e( $options[ $args['id'] ] ); ?></textarea>
<?php }


/*-----------------------------------------------------------------------------------*/
/* The callback function to display selection dropdown */
/*-----------------------------------------------------------------------------------*/

function pafa_settings_field_select( $args ) {
	// Set the options-name value to a variable
	$name = $args['options-name'] . '[' . $args['id'] . ']';

	// Get the options from the database
	$options = get_option( $args['options-name'] ); ?>

	<select name="<?php echo $name; ?>" id="<?php echo $args['id']; ?>" <?php if ( ! empty( $args['class'] ) ) echo 'class="' . $args['class'] . '" '; ?>>
		<?php foreach ( $args['value'] as $key => $value ) : ?>
			<option value="<?php esc_attr_e( $key ); ?>"<?php if ( isset( $options[ $args['id'] ] ) ) selected( $key, $options[ $args['id'] ], true ); ?>><?php esc_attr_e( $value ); ?></option>
		<?php endforeach; ?>
	</select>
	<label for="<?php echo $args['id']; ?>" style="display:block;"><?php esc_attr_e( $args['label'] ); ?></label>
<?php }


/*-----------------------------------------------------------------------------------*/
/* Sanitization function */
/*-----------------------------------------------------------------------------------*/

function pafa_options_sanitize( $input ) {

	// Set array for the sanitized options
	$output = array();

	// Loop through each of $input options and sanitize them.
	foreach ( $input as $key => $value ) {
		if ( isset( $input[ $key ] ) )
			$output[ $key ] = strip_tags( stripslashes( $input[ $key ] ) );
	}

	return apply_filters( 'pafa_options_sanitize', $output, $input );
}

