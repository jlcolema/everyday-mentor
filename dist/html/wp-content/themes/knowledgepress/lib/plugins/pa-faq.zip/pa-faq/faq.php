<?php
/**
 * Plugin Name: PA Faq
 * Plugin URI: http://pressapps.co/plugins/
 * Description: Adds FAQ posts to your site
 * Author: PressApps Team
 * Version: 1.2.0
 */

$pafa_options = get_option( 'pafa_options' );

define( 'PAFA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'PAFA_PLUGIN_URL', plugins_url("", __FILE__) );

define( 'PAFA_PLUGIN_INCLUDES_DIR', PAFA_PLUGIN_DIR . "/includes/" );
define( 'PAFA_PLUGIN_INCLUDES_URL', PAFA_PLUGIN_URL . "/includes/" );

define( 'PAFA_PLUGIN_ASSETS_DIR', PAFA_PLUGIN_DIR . "/assets/" );
define( 'PAFA_PLUGIN_ASSETS_URL', PAFA_PLUGIN_URL . "/assets/" );

define( 'PAFA_PLUGIN_TEMPLATES_DIR', PAFA_PLUGIN_DIR . "/templates/" );
define( 'PAFA_PLUGIN_TEMPLATES_URL', PAFA_PLUGIN_URL . "/templates/" );

class PAFA_FAQ{
    
    /**
     * Setup the Environment for the Faq Plugin
     */
    function __construct() {

        global $pafa_options;

        include_once PAFA_PLUGIN_INCLUDES_DIR . 'functions.php';
        include_once PAFA_PLUGIN_INCLUDES_DIR . 'actions.php';
        include_once PAFA_PLUGIN_INCLUDES_DIR . 'filters.php';
        include_once PAFA_PLUGIN_INCLUDES_DIR . 'help.php';
        if ( $pafa_options['reorder'] == 1 ) {
            include_once PAFA_PLUGIN_INCLUDES_DIR . 'admin/reorder.php';
        }
        if ( is_admin() ) {
            include_once PAFA_PLUGIN_INCLUDES_DIR . 'admin/page.php';
        }

        load_plugin_textdomain( 'pressapps', false, dirname( plugin_basename( __FILE__ ) ) . '/lang/' );
        
        add_action('init' ,array($this,'init'));

        // Add the users custom CSS if they wish to add any.
        if ( $pafa_options['custom-css'] ) {
            add_action( 'wp_head', 'print_faq_custom_css' );
        }

    }
    
    function init(){
        
        add_filter( 'widget_text', 'do_shortcode' );
        
        register_post_type( 'faq',array(
            'description'           => __('FAQ Articles','pressapps'),
            'labels'                => array(
                'name'                  => __('FAQ'                     ,'pressapps'),
                'singular_name'         => __('FAQ'                     ,'pressapps'),
                'add_new'               => __('Add New'                 ,'pressapps'),  
                'add_new_item'          => __('Add New FAQ'             ,'pressapps'),  
                'edit_item'             => __('Edit FAQ'                ,'pressapps'),  
                'new_item'              => __('New FAQ'                 ,'pressapps'),  
                'view_item'             => __('View FAQ'                ,'pressapps'),  
                'search_items'          => __('Search FAQ'              ,'pressapps'),  
                'not_found'             => __('No FAQ found'            ,'pressapps'),  
                'not_found_in_trash'    => __('No FAQ found in Trash'   ,'pressapps')
            ),
            'public'                => true,
            'menu_position'         => 5,
            'rewrite'               => array('slug' => 'faq'),
            'supports'              => array('title','editor' /*,'page-attributes' */),
            'public'                => true,
            'show_ui'               => true,
            'publicly_queryable'    => true,
            'exclude_from_search'   => false
        ));
        
        register_taxonomy( 'faq_category',array( 'faq' ),array( 
            'hierarchical'  => false,
            'labels'        => array(
                'name'              => __( 'Categories'             ,'pressapps'),
                'singular_name'     => __( 'Category'               ,'pressapps'),
                'search_items'      => __( 'Search Categories'      ,'pressapps'),
                'all_items'         => __( 'All Categories'         ,'pressapps'),
                'parent_item'       => __( 'Parent Category'        ,'pressapps'),
                'parent_item_colon' => __( 'Parent Category:'       ,'pressapps'),
                'edit_item'         => __( 'Edit Category'          ,'pressapps'),
                'update_item'       => __( 'Update Category'        ,'pressapps'),
                'add_new_item'      => __( 'Add New Category'       ,'pressapps'),
                'new_item_name'     => __( 'New Category Name'      ,'pressapps'),
                'popular_items'     => NULL,
                'menu_name'         => __( 'Categories'             ,'pressapps') 
            ),
            'show_ui'       => true,
            'public'        => true,
            'query_var'     => true,
            'hierarchical'  => true,
            'rewrite'       => array( 'slug' => 'faq_category' )
        ));
        
        wp_register_style('pafa_default'     , PAFA_PLUGIN_ASSETS_URL . '/css/default.css');
        wp_register_style('pafa_accordion'   , PAFA_PLUGIN_ASSETS_URL . '/css/custom.css');
        wp_register_style('pafa_admin'       , PAFA_PLUGIN_ASSETS_URL . '/css/admin.css');
        wp_register_script('pafa_default'    , PAFA_PLUGIN_ASSETS_URL . '/js/default.js', array('jquery'));
        wp_register_script('pafa_accordion'  , PAFA_PLUGIN_ASSETS_URL . '/js/custom.js', array('jquery'));

    }
}
$pafa_faq = new PAFA_FAQ();