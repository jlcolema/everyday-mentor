<?php

/**
 * 
 * return the Final output of the FAQ html generated based on the template file 
 * and Data based on the parameter
 * 
 * @param array $args
 * @return string
 */
function pafa_get_display_faq($args = array()){
    global $pafa_faq_data;
    global $pafa_settings;
    
    $default = array(
        'category'      => -1,
        'template'      => 'default',
    );
    
    $args = shortcode_atts($default,$args);
    
    if ( $pafa_settings['reorder'] == 1 ) {
        $qry_args = array(
            'post_type'     => 'faq',
            'numberposts'   => -1,
            'orderby' => 'menu_order', 
            'order' => 'ASC', 
        );
    } else {
        $qry_args = array(
            'post_type'     => 'faq',
            'numberposts'   => -1,
        );
    }

    if(isset($args['category']) && $args['category']!=-1){
        $qry_args['tax_query']   = array(array(
                'taxonomy'  => 'faq_category',
                'field'     => 'id',
                'terms'     => $args['category'],
            ),
        );
        $pressapps_terms       = get_terms('faq_category',array(
            'child_of'  => $args['category']
        ));
        if ( $pafa_settings['reorder'] == 1 ) {
            $pressapps_terms       = get_terms('faq_category',array(
                'child_of'  => $args['category'],
                'orderby'   => 'term_group',
                'order' => 'ASC'
            ));
        } else {
            $pressapps_terms       = get_terms('faq_category',array(
                'child_of'  => $args['category']
            ));
        }
    }else{

        if ( $pafa_settings['reorder'] == 1 ) {
            $pressapps_terms = get_terms('faq_category' ,array(
                'orderby'   => 'term_group',
                'order' => 'ASC'
            ) );
        } else {
            $pressapps_terms = get_terms('faq_category');
        }

    }
    
    if(count($pressapps_terms)>0){
        foreach($pressapps_terms as $term){
            $pressapps_terms_questions[$term->term_id] = get_posts(array_merge($qry_args,
                array('tax_query'     => array(
                    array(
                        'taxonomy'  => 'faq_category',
            			'field'     => 'id',
            			'terms'     => $term->term_id,
                    )
                )
            )));
            
        }
        
        $pafa_faq_data = array(
            'dispaly_terms' => TRUE,
            'terms'         => $pressapps_terms,
            'questions'     => $pressapps_terms_questions,
            'template'      => $args['template'],
        );
    }else{
        
        $pressapps_question = get_posts($qry_args);
        
        $pafa_faq_data = array(
            'dispaly_terms' => FALSE,
            'questions'     => $pressapps_question,
            'template'      => $args['template'],
        );
    }
    
    /**
     * Select the Proper Template file to be Render the FAQ Structure
     * 
     */
    
    $default_filename           = PAFA_PLUGIN_TEMPLATES_DIR . "/pressappsfaq-default.php";  
    $theme_default_filename     = get_stylesheet_directory() . "/pressappsfaq-default.php";
    
    $default_template_filename  = PAFA_PLUGIN_TEMPLATES_DIR . "/pressappsfaq-{$args['template']}.php";
    $theme_template_filename    = get_stylesheet_directory() . "/pressappsfaq-{$args['template']}.php";
    
    if(@file_exists($theme_template_filename)){
        $filename = $theme_template_filename;
    }elseif(@file_exists($default_template_filename)){
        $filename = $default_template_filename;
    }elseif(@file_exists($theme_default_filename)){
        $filename = $theme_default_filename;
    }else{
        $filename = $default_filename;
    }
    
    
    ob_start();
    include_once $filename;

    if($pafa_faq_data['template']=='default'){
        wp_enqueue_style('pafa_default');
        wp_enqueue_script('pafa_default');
    } elseif ($pafa_faq_data['template']=='accordion'){
        wp_enqueue_style('pafa_accordion');
        wp_enqueue_script('pafa_accordion');
    } 
    if(is_admin()){
        wp_enqueue_style('pafa_admin');
    } 
    wp_reset_query();
    return ob_get_clean();
    
}

/**
 * 
 * Disply the FAQ HTML generated based on the template file of FAQ.
 * 
 * @param array $args
 */
function pafa_the_display_faq($args   = array()){
    echo pafa_get_display_faq($args);
}

/**
 * Add the Shortcode for the Faq part with the following options 
 * 
 * <ul>
 * <li></li>
 * <li></li>
 * <li></li>
 * </ul>
 * 
 * @param array $atts
 * @return string
 */
function pafa_shortcode_faq($atts = array()){
    return pafa_get_display_faq($atts);
}

add_shortcode('faq', 'pafa_shortcode_faq');


function pafa_custom_css() {

    global $pafa_settings;

    echo '<style text="text/css" id="faq-custom-css">' . "\n" . sanitize_text_field( $pafa_settings['custom-css'] ) . "\n</style>\n";
}
