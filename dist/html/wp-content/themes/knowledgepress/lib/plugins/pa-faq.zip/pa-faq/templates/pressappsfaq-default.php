<?php

global $pafa_faq_data,$post;

if(count($pafa_faq_data['questions'])==0){
    _e('No Faq Found','pressapps');
    return ;
}
?>
<a id="top_faq"></a>
<?php
if(isset($pafa_faq_data['terms'])){
    ?>
    <ul class="faq-category-list">
    <?php
    $i=1;
    foreach($pafa_faq_data['terms'] as $terms){
        
        if(count($pafa_faq_data['questions'][$terms->term_id])>0){
            ?>
            <li>
                <h2 class="faq-section-heading">
                    <a href="#<?php echo $terms->slug . $i++ ; ?>"><?php echo $terms->name; ?></a>
                </h2>
                <ul class="question-list">
            <?php
                foreach($pafa_faq_data['questions'][$terms->term_id] as $post){
                    setup_postdata($post);
                   ?>
                    <li><h4 id="faq-<?php the_ID(); ?>" class="entry-title"><a href="#question-<?php the_ID(); ?>"><?php the_title()?></a></h4></li>
                   <?php
                }
            ?>
                </ul>
            </li>
            <?php
        }
    }
        ?>
    </ul>
        <div class="question-detail-list">
            <?php
            $i=1;
            foreach($pafa_faq_data['terms'] as $terms){
                if(count($pafa_faq_data['questions'][$terms->term_id])>0){  
                    ?>
                    <h2 id="<?php echo $terms->slug . $i++ ; ?>" class="faq-section-heading">
                    <?php echo $terms->name; ?>
                    </h2>
                    <?php
                    foreach($pafa_faq_data['questions'][$terms->term_id] as $post){
                        setup_postdata($post);
                        ?>
                    <article id="faqarticle-<?php the_ID(); ?>" class="faq type-pressapps_faq status-publish clearfix">
                    <h3 id="question-<?php the_ID(); ?>" class="entry-title"><a name="<?php the_ID(); ?>"></a><?php the_title(); ?></h3>
                    <div class="faq-content">
                    <?php the_content(); ?>
                    <a class="faq-back-top" href="#top_faq">Back To Top</a>
                    </div>
                    </article>
                        <?php
                    }
                } 
            }
            ?>
        </div>
        <?php
    
}else{

    ?>
    <ul class="faq-single-list">
    <?php
    foreach($pafa_faq_data['questions'] as $post){
        setup_postdata($post);
       ?>
        <li><h4 id="faq-<?php the_ID(); ?>" class="entry-title"><a href="#question-<?php the_ID(); ?>"><?php the_title()?></a></h4></li>
       <?php
    }

        ?>
    </ul>
    <?php
    foreach($pafa_faq_data['questions'] as $post){
        setup_postdata($post);
        ?>
    <article id="faqarticle-<?php the_ID(); ?>" class="faq type-pressapps_faq status-publish clearfix">
    <h3 id="question-<?php the_ID(); ?>" class="entry-title"><a name="<?php the_ID(); ?>"></a><?php the_title(); ?></h3>
    <div class="faq-content">
    <?php the_content(); ?>
    <a class="faq-back-top" href="#top_faq">Back To Top</a>
    </div>
    </article>
        <?php
    }
}